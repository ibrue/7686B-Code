#include "EZ-Template/util.hpp"
#include "main.h"


/////
// For instalattion, upgrading, documentations and tutorials, check out website!
// https://ez-robotics.github.io/EZ-Template/
/////


const int DRIVE_SPEED = 120; // This is 110/127 (around 87% of max speed).  We don't suggest making this 127.
                             // If this is 127 and the robot tries to heading correct, it's only correcting by
                             // making one side slower.  When this is 87%, it's correcting by making one side
                             // faster and one side slower, giving better heading correction.
const int TURN_SPEED  = 100;
const int SWING_SPEED = 100;



///
// Constants
///

// It's best practice to tune constants when the robot is empty and with heavier game objects, or with lifts up vs down.
// If the objects are light or the cog doesn't change much, then there isn't a concern here.

void default_constants() {
  chassis.set_slew_min_power(90, 90);
  chassis.set_slew_distance(3, 3);
  chassis.set_pid_constants(&chassis.headingPID, 4.5, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.35, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 4.5, 0.004, 49, 12);
  chassis.set_pid_constants(&chassis.swingPID, 4.5, 0, 45, 0);
}

void one_mogo_constants() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 35, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}

void two_mogo_constants() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 9, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.004, 40, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}

void exit_condition_defaults() {
  chassis.set_exit_condition(chassis.turn_exit, 10, 2, 90, 7, 500, 500);
  chassis.set_exit_condition(chassis.swing_exit, 10, 3, 90, 7, 500, 500);
  chassis.set_exit_condition(chassis.drive_exit, 10, 25, 90, 150, 500, 500);
}

void modified_exit_condition() {
  chassis.set_exit_condition(chassis.turn_exit, 100, 3, 500, 7, 500, 500);
  chassis.set_exit_condition(chassis.swing_exit, 100, 3, 500, 7, 500, 500);
  chassis.set_exit_condition(chassis.drive_exit, 80, 50, 300, 150, 500, 500);
}



///
// Drive Example
///
void RollerStart() {
// When the robot gets to 6 inches, the robot will travel the remaining distance at a max speed of 40
  chassis.set_drive_pid(3, DRIVE_SPEED, true);
  chassis.wait_drive();

  Intake.move_relative(-4, 600);
  Intake.move_relative(-4, 600);
	pros::delay(400);
 
  chassis.set_drive_pid(-7, DRIVE_SPEED, false);
  chassis.wait_drive();

  chassis.set_turn_pid(-191, TURN_SPEED);
  chassis.wait_drive();
    
chassis.set_drive_pid(-4, DRIVE_SPEED, true);
  chassis.wait_drive();



    //shoot  
powerlimit.set_value(false);
power.set_value(true);
powertwo.set_value(true);
Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
pros::delay(500);
power.set_value(false);
powertwo.set_value(false);


pros::delay(200);

  chassis.set_turn_pid(-137, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(22, 90, true);
 Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(4);
    Flywheel.brake();
    Intake.brake();

      pros::delay(100);

     Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(4);
    Flywheel.brake();
    Intake.brake();
      Flywheel.move_relative(-35, 600);
  Intake.move_relative(-35, 600);
  chassis.wait_drive();


  chassis.set_drive_pid(25, 30, false);
  chassis.wait_drive();


    chassis.set_drive_pid(-20, DRIVE_SPEED, false);
    chassis.wait_drive();

     pros::delay(5000);

    
    chassis.set_drive_pid(20, DRIVE_SPEED, false);
    chassis.wait_drive();

  chassis.set_turn_pid(-215, TURN_SPEED);
  chassis.wait_drive();

    pros::delay(100);


  //shoot
  chassis.set_drive_pid(6, DRIVE_SPEED, false);
    chassis.wait_drive();

powerlimit.set_value(false);
power.set_value(true);
powertwo.set_value(true);
Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
pros::delay(500);
power.set_value(false);
powertwo.set_value(false);

pros::delay(200);


  chassis.set_drive_pid(-20, DRIVE_SPEED, false);
  Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();

      pros::delay(100);

     Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();
    chassis.wait_drive();


}



void WallStart() {
// When the robot gets to 6 inches, the robot will travel the remaining distance at a max speed of 40
  chassis.set_drive_pid(3, DRIVE_SPEED, true);
  chassis.wait_drive();

  Intake.move_relative(-4, 600);
  Intake.move_relative(-4, 600);
	pros::delay(400);
 
  chassis.set_drive_pid(-7, DRIVE_SPEED, false);
  chassis.wait_drive();

  chassis.set_turn_pid(-191, TURN_SPEED);
  chassis.wait_drive();
    
chassis.set_drive_pid(-4, DRIVE_SPEED, true);
  chassis.wait_drive();



    //shoot  
powerlimit.set_value(false);
power.set_value(true);
powertwo.set_value(true);
Flywheel.move_relative(5, 600);
Intake.move_relative(5, 600);
pros::delay(500);
power.set_value(false);
powertwo.set_value(false);


pros::delay(200);

}



void WinPoint() {
// When the robot gets to 6 inches, the robot will travel the remaining distance at a max speed of 40
  chassis.set_drive_pid(3, DRIVE_SPEED, true);
  chassis.wait_drive();

  Intake.move_relative(-4, 600);
  Intake.move_relative(-4, 600);
	pros::delay(400);
 
  chassis.set_drive_pid(-7, DRIVE_SPEED, false);
  chassis.wait_drive();

  chassis.set_turn_pid(-191, TURN_SPEED);
  chassis.wait_drive();
    
chassis.set_drive_pid(-4, DRIVE_SPEED, true);
  chassis.wait_drive();



    //shoot  
powerlimit.set_value(false);
power.set_value(true);
powertwo.set_value(true);
Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
pros::delay(500);
power.set_value(false);
powertwo.set_value(false);


pros::delay(200);

  chassis.set_turn_pid(-137, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(20.7, 95, true);
 Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();

      pros::delay(100);

     Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(3);
    Flywheel.brake();
    Intake.brake();
  Flywheel.move_relative(-35, 600);
  Intake.move_relative(-35, 600);
  chassis.wait_drive();

  chassis.set_drive_pid(25, 30, false);
  chassis.wait_drive();

  chassis.set_turn_pid(-215, TURN_SPEED);
  chassis.wait_drive();

    pros::delay(100);


  //shoot
  chassis.set_drive_pid(3, DRIVE_SPEED, false);
    chassis.wait_drive();

powerlimit.set_value(false);
power.set_value(true);
powertwo.set_value(true);
Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
pros::delay(500);
power.set_value(false);
powertwo.set_value(false);


   chassis.set_drive_pid(-6, DRIVE_SPEED, false);
  chassis.wait_drive();
    chassis.set_turn_pid(-136, TURN_SPEED);
  chassis.wait_drive();

   chassis.set_drive_pid(17, DRIVE_SPEED, true);
    Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();
      pros::delay(100);
     Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(3);
    Flywheel.brake();
    Intake.brake();
  Flywheel.move_relative(-45, 600);
  Intake.move_relative(-45, 600);
  chassis.wait_drive();

    chassis.set_drive_pid(30, 60, false);
  chassis.wait_drive();

  chassis.set_turn_pid(-245, TURN_SPEED);
  chassis.wait_drive();


  //shoot
  chassis.set_drive_pid(8, DRIVE_SPEED, true);
      pros::delay(50);

powerlimit.set_value(false);
power.set_value(true);
powertwo.set_value(true);
Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
pros::delay(500);
power.set_value(false);
powertwo.set_value(false);
pros::delay(300);

 chassis.set_drive_pid(-4, DRIVE_SPEED, false);
  chassis.wait_drive();

    chassis.set_turn_pid(-135, TURN_SPEED);
  chassis.wait_drive();
  

   chassis.set_drive_pid(39, 105, true);
    Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();

      pros::delay(100);


     Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(3);
    Flywheel.brake();
    Intake.brake();
  chassis.wait_drive();


  Intake.brake();
  Flywheel.brake();
  chassis.set_turn_pid(-90, TURN_SPEED);
  chassis.wait_drive();


 chassis.set_drive_pid(7, DRIVE_SPEED, true);
	pros::delay(300);
    Intake.move_relative(-4, 600);
  Intake.move_relative(-4, 600);
}



void Skills() {

//NEAR ROLLERS

  //Drive to starting roller to press up in it
  chassis.set_drive_pid(3.7, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Spin roller + wait to back away from it
  Intake.move_relative(-6, 600);
  Flywheel.move_relative(-6, 600);
  pros::delay(500);

  //Back away from first roller, but not too far so to not touch stack of three
  chassis.set_drive_pid(-12, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Position to second starting roller
  chassis.set_turn_pid(92, TURN_SPEED);

  //Turn intake on to collect that one disk in the middle of the rollers
  Intake.move_relative(-15, 600);
  Flywheel.move_relative(-15, 600);
  chassis.wait_drive();

  //Drive forward to second starting roller
  chassis.set_drive_pid(25.8, 90, true);
  chassis.wait_drive();

  // Stop intake so it doesn't spin roller
  Intake.brake();
  Flywheel.brake();


  chassis.set_turn_pid(90, TURN_SPEED);


  //Drive forward to roller slow
  chassis.set_drive_pid(7, 60, false);
  chassis.wait_drive();

  //Turn roller + wait until moving away from it
  Intake.move_relative(-6, 600);
  Flywheel.move_relative(-6, 600);
  pros::delay(500);



//1ST SHOT

  //Move away from second starting roller
  chassis.set_drive_pid(-4.5, 90, true);
  chassis.wait_drive();

  //Turn to face high goal
  chassis.set_turn_pid(178, TURN_SPEED);
  chassis.wait_drive();

  //Drive to high goal
  chassis.set_drive_pid(64.6, 85, true);

  //Turn on intake while driving to make sure 3rd disk is in the right positon
  Intake.move_relative(-10, 600);  
  Flywheel.move_relative(-10, 600);  
  chassis.wait_drive();

  //Brake the intake, then shoot
  Intake.brake();
  Flywheel.brake();

  chassis.set_turn_pid(192, TURN_SPEED);
  chassis.wait_drive();

  //Shoot
    Flywheel.move_relative(10.7, 600);
    Intake.move_relative(10.7, 600);
        pros::delay(500);






//2ND SHOT

  //Move backwards to be in line with the line of three disks at a 45 degree angle
  chassis.set_drive_pid(-4, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Turn so intake is facing the direction of the line of disks
  chassis.set_turn_pid(245, TURN_SPEED);
  chassis.wait_drive();

    Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();

     chassis.set_drive_pid(5.9, DRIVE_SPEED, true);
  chassis.wait_drive();

  chassis.set_turn_pid(266.5, TURN_SPEED);
  chassis.wait_drive();

  //Move backwards to be in line with the line of three disks at a 45 degree angle
  chassis.set_drive_pid(28, 39, false);
  Intake.move_relative(-38, 600);  
  Flywheel.move_relative(-38, 600);
  chassis.wait_drive();
  pros::delay(300);


  //Move backwards to be in line with the line of three disks at a 45 degree angle
  chassis.set_drive_pid(-30, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Turn to face high goal
  chassis.set_turn_pid(190, TURN_SPEED);
  chassis.wait_drive();

 //Brake the intake, then shoot
  Intake.brake();
  Flywheel.brake();

  //Shoot
    Flywheel.move_relative(10.7, 600);
    Intake.move_relative(10.7, 600);


        pros::delay(300);

 chassis.set_turn_pid(165, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(-39.6, DRIVE_SPEED, true);
  Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();
  Intake.move_relative(-50, 600);  
  Flywheel.move_relative(-50, 600);
  chassis.wait_drive();

  chassis.set_turn_pid(225, TURN_SPEED);
  chassis.wait_drive();

    

  chassis.set_drive_pid(49, 50, true);
  chassis.wait_drive();
  
  chassis.set_turn_pid(134, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(4.8, DRIVE_SPEED, true);
      chassis.wait_drive();

    //Shoot
powerlimit.set_value(true);
pros::delay(150);
Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
power.set_value(true);
powertwo.set_value(true);
pros::delay(500);
power.set_value(false);
powertwo.set_value(false);
powerlimit.set_value(false);


    pros::delay(750);



  chassis.set_turn_pid(177, TURN_SPEED);
  chassis.wait_drive();


  chassis.set_drive_pid(39, 39, false);
   Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();


  Intake.move_relative(-35, 600);  
  Flywheel.move_relative(-35, 600);
  chassis.wait_drive();
  
  chassis.set_turn_pid(87, TURN_SPEED);
  chassis.wait_drive();

   //Brake the intake, then shoot
  Intake.brake();
  Flywheel.brake();

  //Shoot
    Flywheel.move_relative(10.7, 600);
    Intake.move_relative(10.7, 600);
    pros::delay(400);


  chassis.set_drive_pid(-11, DRIVE_SPEED, true);
  chassis.wait_drive();


















  chassis.set_swing_pid(ez::LEFT_SWING, 0, SWING_SPEED);
  Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();

  chassis.wait_drive();

  chassis.set_drive_pid(-6, DRIVE_SPEED, true);
  chassis.wait_drive();

    pros::delay(400);

    chassis.set_swing_pid(ez::LEFT_SWING, 84, SWING_SPEED);
  chassis.wait_drive();


   chassis.set_drive_pid(12, DRIVE_SPEED, true);
  chassis.wait_drive();


Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
pros::delay(300);

   chassis.set_drive_pid(-9.4, DRIVE_SPEED, true);
  chassis.wait_drive();

  chassis.set_swing_pid(ez::LEFT_SWING, 0, SWING_SPEED);
  Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();

  chassis.wait_drive();

    chassis.set_drive_pid(-7, DRIVE_SPEED, true);
  chassis.wait_drive();

    pros::delay(400);

    chassis.set_swing_pid(ez::LEFT_SWING, 84, SWING_SPEED);
  chassis.wait_drive();

   chassis.set_drive_pid(12, DRIVE_SPEED, true);
  chassis.wait_drive();

 
Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
pros::delay(200);

  
  chassis.set_turn_pid(95, TURN_SPEED);
  chassis.wait_drive();

 chassis.set_drive_pid(-48.5, DRIVE_SPEED, true);
 Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();
    pros::delay(100);
    Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(3);
    Flywheel.brake();
    Intake.brake();
  chassis.wait_drive();

chassis.set_turn_pid(180, TURN_SPEED);
  chassis.wait_drive();








    //Drive forward to second starting roller
  chassis.set_drive_pid(6, DRIVE_SPEED, true);
  chassis.wait_drive();

  chassis.set_angle(0);

  //Drive forward to roller slow
  chassis.set_drive_pid(5, 60, false);
  chassis.wait_drive();

  //Turn roller + wait until moving away from it
  Intake.move_relative(-6, 600);
  Flywheel.move_relative(-6, 600);
  pros::delay(600);


  chassis.set_drive_pid(-10, DRIVE_SPEED, true);
  chassis.wait_drive();

  chassis.set_turn_pid(180, TURN_SPEED);
   Intake.move_relative(-50, 600);
 Flywheel.move_relative(-50, 600);
  chassis.wait_drive();
  
  chassis.set_drive_pid(10, DRIVE_SPEED, true);
  chassis.wait_drive();

 chassis.set_drive_pid(17.5, 21, false);
 chassis.wait_drive();

   pros::delay(200);

   
  chassis.set_drive_pid(-5, DRIVE_SPEED, false);
  chassis.wait_drive();


    chassis.set_turn_pid(170, TURN_SPEED);
  chassis.wait_drive();

 
powerlimit.set_value(false);
power.set_value(true);
powertwo.set_value(true);
Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
pros::delay(500);
power.set_value(false);
powertwo.set_value(false);
pros::delay(300);

  chassis.set_turn_pid(180, TURN_SPEED);
  chassis.wait_drive();
   
  chassis.set_drive_pid(-4, DRIVE_SPEED, false);
  chassis.wait_drive();


   chassis.set_turn_pid(90, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(23, DRIVE_SPEED, true);
       Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();
  chassis.wait_drive();

  //Drive forward to roller slow
  chassis.set_drive_pid(6.5, 60, false);
  chassis.wait_drive();

  //Turn roller + wait until moving away from it
  Intake.move_relative(-6, 600);
  Flywheel.move_relative(-6, 600);
  pros::delay(600);

  chassis.set_drive_pid(-6, DRIVE_SPEED, true);
  chassis.wait_drive();


chassis.set_turn_pid(225, TURN_SPEED);
  Intake.move_relative(-60, 600);  
  Flywheel.move_relative(-60, 600);
  chassis.wait_drive();



  chassis.set_drive_pid(60, 55, false);
  chassis.wait_drive();

  pros::delay(200);


  chassis.set_turn_pid(135, TURN_SPEED);
  chassis.wait_drive();

   //Brake the intake, then shoot
  Intake.brake();
  Flywheel.brake();

  
  chassis.set_drive_pid(-7, DRIVE_SPEED, true);
  chassis.wait_drive();


  chassis.set_drive_pid(10, DRIVE_SPEED, false);
pros::delay(20);

    //Shoot
powerlimit.set_value(true);
pros::delay(50);
Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
power.set_value(true);
powertwo.set_value(true);
pros::delay(500);
power.set_value(false);
powertwo.set_value(false);
powerlimit.set_value(false);

      chassis.wait_drive();


    pros::delay(200);

  chassis.set_turn_pid(177, TURN_SPEED);
  chassis.wait_drive();


  chassis.set_drive_pid(40.5, 40, false);
   Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();


  Intake.move_relative(-35, 600);  
  Flywheel.move_relative(-35, 600);
  chassis.wait_drive();
  
  chassis.set_turn_pid(85, TURN_SPEED);
  chassis.wait_drive();

   //Brake the intake, then shoot
  Intake.brake();
  Flywheel.brake();

  //Shoot
    Flywheel.move_relative(10.7, 600);
    Intake.move_relative(10.7, 600);
    pros::delay(300);

 chassis.set_turn_pid(105, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(-11.5, DRIVE_SPEED, true);
  chassis.wait_drive();

  

  chassis.set_swing_pid(ez::LEFT_SWING, 0, SWING_SPEED);
  Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();

  chassis.wait_drive();

  chassis.set_drive_pid(-9, DRIVE_SPEED, true);
  chassis.wait_drive();

    pros::delay(300);

    chassis.set_swing_pid(ez::LEFT_SWING, 83, SWING_SPEED);
  chassis.wait_drive();


   chassis.set_drive_pid(12, DRIVE_SPEED, true);
  chassis.wait_drive();

Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
    pros::delay(300);


   chassis.set_drive_pid(-9, DRIVE_SPEED, true);
  chassis.wait_drive();

  chassis.set_swing_pid(ez::LEFT_SWING, 0, SWING_SPEED);
  Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();

  chassis.wait_drive();

    chassis.set_drive_pid(-6, DRIVE_SPEED, true);
  chassis.wait_drive();

    pros::delay(400);

    chassis.set_swing_pid(ez::LEFT_SWING, 83, SWING_SPEED);
  chassis.wait_drive();

   chassis.set_drive_pid(12, DRIVE_SPEED, true);
  chassis.wait_drive();

Flywheel.move_relative(10.7, 600);
Intake.move_relative(10.7, 600);
    pros::delay(300);


  
  chassis.set_turn_pid(103, TURN_SPEED);
  chassis.wait_drive();

 chassis.set_drive_pid(-60, DRIVE_SPEED, true);
 Flywheel.move(127);
    Intake.move(127);
    while (pressy.get_value()==false) {
    pros::delay(10);
    }
    pros::delay(5);
    Flywheel.brake();
    Intake.brake();

    
  chassis.wait_drive();

    chassis.set_turn_pid(225, TURN_SPEED);
  chassis.wait_drive();


   chassis.set_drive_pid(12, DRIVE_SPEED, true);
  chassis.wait_drive();

      release.set_value(true);
        pros::delay(200);


    chassis.set_drive_pid(-12, DRIVE_SPEED, true);
  chassis.wait_drive();
expand.set_value(true);
expandtwo.set_value(true);

  
}





