//Helpy functions
void setFlywheel(int speed);
void setIntake(int index);
//Driver Control functions
void SetFlywheelMotors();
