#include "main.h"
#include "pros/adi.h"
#include "pros/adi.hpp"
#include "pros/misc.h"
#include "pros/motors.h"

//Helpy functions
void setFlywheel(int speed){
  Flywheel = speed;
  }

void setIntake(int index){
  Intake = index;
  }


//Driver Control functions
void SetFlywheelMotors(){
  int flywheelpower;
  int intakepower;

if(pressy.get_value() == false){
intakepower = 0;
flywheelpower = 127;

}

else if(pressy.get_value() == true){
if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)){
Flywheel.move_relative(2, 600);
pros::delay(200);
}

else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2)){
power.set_value(true);
pros::delay(300);
Flywheel.move_relative(2, 600);
pros::delay(300);
power.set_value(false);

}

else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_A)){
Flywheel.move_relative(2, 600);
pros::delay(150);
expand.set_value(true);
expandtwo.set_value(true);
pros::delay(500);
expand.set_value(false);
expand.set_value(false);




}

else {
intakepower = 0;
flywheelpower = 0;

}

}

if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L1)){
intakepower = 127;
}

if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2)){
intakepower = -127;
}


setFlywheel(flywheelpower);
setIntake(intakepower);


}
