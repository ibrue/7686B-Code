#include "main.h"
#include "pros/adi.hpp"

//Defining motors actually this time
pros::Motor Intake (19, pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_ROTATIONS);
pros::Motor Flywheel (20, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_ROTATIONS);


//Defining Controller
pros::Controller controller(pros::E_CONTROLLER_MASTER);

//Defining Pneumatics
pros::ADIDigitalOut expand('B'); 
pros::ADIDigitalOut expandtwo('D'); 

pros::ADIDigitalOut power('C'); 

//Defining Stop
pros::ADIButton pressy('A'); 



