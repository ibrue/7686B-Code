#include "EZ-Template/util.hpp"
#include "main.h"


/////
// For instalattion, upgrading, documentations and tutorials, check out website!
// https://ez-robotics.github.io/EZ-Template/
/////


const int DRIVE_SPEED = 110; // This is 110/127 (around 87% of max speed).  We don't suggest making this 127.
                             // If this is 127 and the robot tries to heading correct, it's only correcting by
                             // making one side slower.  When this is 87%, it's correcting by making one side
                             // faster and one side slower, giving better heading correction.
const int TURN_SPEED  = 90;
const int SWING_SPEED = 90;



///
// Constants
///

// It's best practice to tune constants when the robot is empty and with heavier game objects, or with lifts up vs down.
// If the objects are light or the cog doesn't change much, then there isn't a concern here.

void default_constants() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 35, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}

void one_mogo_constants() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 35, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}

void two_mogo_constants() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 35, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}

void exit_condition_defaults() {
  chassis.set_exit_condition(chassis.turn_exit, 100, 3, 500, 7, 500, 500);
  chassis.set_exit_condition(chassis.swing_exit, 100, 3, 500, 7, 500, 500);
  chassis.set_exit_condition(chassis.drive_exit, 80, 50, 300, 150, 500, 500);
}

void modified_exit_condition() {
  chassis.set_exit_condition(chassis.turn_exit, 100, 3, 500, 7, 500, 500);
  chassis.set_exit_condition(chassis.swing_exit, 100, 3, 500, 7, 500, 500);
  chassis.set_exit_condition(chassis.drive_exit, 80, 50, 300, 150, 500, 500);
}



///
// Drive Example
///
void RollerStart() {
// When the robot gets to 6 inches, the robot will travel the remaining distance at a max speed of 40
  chassis.set_drive_pid(2, DRIVE_SPEED, true);
  chassis.wait_drive();

  Intake.move_relative(-1.5, 600);
	pros::delay(300);
 
  chassis.set_drive_pid(-7, 40, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-11, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(-8, 40, true);
  pros::delay(100);
  power.set_value(true);
  Flywheel.move_relative(18.05, 600);
  pros::delay(250);
  power.set_value(false);
  Intake.move_relative(55, 600);
  pros::delay(500);
  chassis.wait_drive();



  chassis.set_turn_pid(-115, TURN_SPEED);
  chassis.wait_drive();



  chassis.set_drive_pid(19, DRIVE_SPEED, true);
  chassis.wait_drive();

  pros::delay(500);

  
  chassis.set_drive_pid(6, 25, true);
  chassis.wait_drive();

  pros::delay(500);
  
  chassis.set_drive_pid(-2, 50, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-23, TURN_SPEED);
  chassis.wait_drive();

  
  chassis.set_drive_pid(-3, DRIVE_SPEED, true);
  chassis.wait_drive();

  Intake.brake();
  power.set_value(true);
  Flywheel.move_relative(18, 600);
  pros::delay(250);
  power.set_value(false);
  pros::delay(750);
  Intake.move_relative(55, 600);

    chassis.set_drive_pid(-5, DRIVE_SPEED, true);
  chassis.wait_drive();

 chassis.set_turn_pid(-97, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(32, 40, true);
  chassis.wait_drive();
  
  pros::delay(300);

  
  chassis.set_drive_pid(-15, 40, true);
  chassis.wait_drive();
  

  chassis.set_turn_pid(-34, TURN_SPEED);
  chassis.wait_drive();
  

  Intake.brake();
  power.set_value(true);
  Flywheel.move_relative(18, 600);
  pros::delay(250);
  power.set_value(false);
  pros::delay(100);






  //chassis.set_max_speed(40); // After driving 6 inches at DRIVE_SPEED, the robot will go the remaining distance at 40 speed
 


}



void WallStart() {


}



void WinPoint() {
chassis.set_drive_pid(2, DRIVE_SPEED, true);
  chassis.wait_drive();

  Intake.move_relative(-1.5, 600);
	pros::delay(300);
 
  chassis.set_drive_pid(-6, 40, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-12, TURN_SPEED);
  chassis.wait_drive();

 chassis.set_drive_pid(-8, 40, true);

  power.set_value(true);
  Flywheel.move_relative(18.05, 600);
  pros::delay(250);
  power.set_value(false);
  Intake.move_relative(55, 600);
  pros::delay(500);

  chassis.wait_drive();


  chassis.set_turn_pid(-115, TURN_SPEED);
  chassis.wait_drive();



  chassis.set_drive_pid(19, DRIVE_SPEED, true);
  chassis.wait_drive();

  pros::delay(500);

  
  chassis.set_drive_pid(7, 25, true);
  chassis.wait_drive();

  pros::delay(1000);

 

  chassis.set_turn_pid(-25, TURN_SPEED);
  chassis.wait_drive();

   chassis.set_drive_pid(-2, 50, true);
  chassis.wait_drive();

  Intake.brake();
  power.set_value(true);
  Flywheel.move_relative(18, 600);
  pros::delay(250);
  power.set_value(false);
  pros::delay(1000);

  
  chassis.set_drive_pid(-7, DRIVE_SPEED, true);
  chassis.wait_drive();


  chassis.set_turn_pid(-132, 70);
  chassis.wait_drive();

  chassis.set_drive_pid(99, DRIVE_SPEED, true);
  Intake.move_relative(70, 600);
  chassis.wait_drive();

  chassis.set_turn_pid(-90, TURN_SPEED);
  chassis.wait_drive();
  Intake.brake();

  chassis.set_drive_pid(12, DRIVE_SPEED, true);
  chassis.wait_until(3);
  Intake.brake();
  pros::delay(1000);

  

  Intake.move_relative(-2, 600);
  pros::delay(500);

 
  chassis.set_drive_pid(-10, DRIVE_SPEED, true);

}



void Skills() {

//NEAR ROLLERS

  //Drive to starting roller to press up in it
  chassis.set_drive_pid(3, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Spin roller + wait to back away from it
  Intake.move_relative(-2.5, 600);
  pros::delay(500);

  //Back away from first roller, but not too far so to not touch stack of three
  chassis.set_drive_pid(-12, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Position to second starting roller
  chassis.set_turn_pid(92, TURN_SPEED);

  //Turn intake on to collect that one disk in the middle of the rollers
  Intake.move_relative(40, 600);
  chassis.wait_drive();

  //Drive forward to second starting roller
  chassis.set_drive_pid(29, DRIVE_SPEED, true);
  chassis.wait_drive();

  // Stop intake so it doesn't spin roller
  Intake.brake();

  chassis.set_turn_pid(90, TURN_SPEED);


  //Drive forward to roller slow
  chassis.set_drive_pid(3, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Turn roller + wait until moving away from it
  Intake.move_relative(-2.5, 600);
  pros::delay(500);



//1ST SHOT

  //Move away from second starting roller
  chassis.set_drive_pid(-8, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Turn to face high goal
  chassis.set_turn_pid(0, TURN_SPEED);
  chassis.wait_drive();

  //Drive to high goal
  chassis.set_drive_pid(-65, DRIVE_SPEED, true);

  //Turn on intake while driving to make sure 3rd disk is in the right positon
  Intake.move_relative(20, 600);  
  chassis.wait_drive();

  //Brake the intake, then shoot
  Intake.brake();
  Flywheel.move_relative(18.05, 600);

  //Delay before doing anything after
  pros::delay(300);

//2ND SHOT

  //Move backwards to be in line with the line of three disks at a 45 degree angle
  chassis.set_drive_pid(43, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Turn so intake is facing the direction of the line of disks
  chassis.set_turn_pid(-135, TURN_SPEED);
  chassis.wait_drive();

  //Move intake forwards to collect the disks
  Intake.move_relative(70, 600);

  //Go across the line of disks far enough to be in the center of the field and also slow enough to collect them
  chassis.set_drive_pid(56, 80, true);

  //Wait to slow the drive down until it gets to the first disk, then run drive at 40 percent
  chassis.wait_until(20);
  chassis.set_max_speed(40);
  chassis.wait_drive();

  //Line up to goal in the middle
  chassis.set_turn_pid(-45, TURN_SPEED);
  chassis.wait_drive();

  //Go forward for a better shot because it don't shoot that far
  chassis.set_drive_pid(-5, 80, true);
  chassis.wait_drive();

  //Stop intake before shooting
  Intake.brake();

  //Shoot and don't do anything after for a little bit
  Flywheel.move_relative(18, 600);
  pros::delay(300);
  
//3RD SHOT

  //Back up from where it shot to be in line with the 3 disks
  chassis.set_drive_pid(6, 80, true);
  chassis.wait_drive();

  //Turn to be in line with the three disks 
  chassis.set_turn_pid(-135, TURN_SPEED);
  chassis.wait_drive();

  //Turn on intake to pick up three stack of disks
  Intake.move_relative(70, 600);

  //Drive forward just enough at full speed to knock the three stack down
  chassis.set_drive_pid(31, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Wait until first disk is picked up
  pros::delay(500);

  //Move forward picking up the other two disks and also be in line with the goal
  chassis.set_drive_pid(27, 30, true);
  chassis.wait_drive();

  //Turn to face goal and line up for shooting
  chassis.set_turn_pid(-90, TURN_SPEED);
  chassis.wait_drive();

  //Drive forward almost to low goal to line up shot
  chassis.set_drive_pid(-37, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Turn intake off before shooting
  Intake.brake();

  //Shoot and also turn a little more so the ratchet is not bad for the next shot idk why this works but it does 
  Flywheel.move_relative(18.02, 600);
  pros::delay(300);

//FAR ROLLERS

  //After the shot, go forward
  chassis.set_drive_pid(17, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Turn a little to the right so we can line up with the roller
  chassis.set_turn_pid(-80, TURN_SPEED);
  chassis.wait_drive();

  //Drive forward to line up with roller horizontally
  chassis.set_drive_pid(30, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Turn back straight to be in line with roller
  chassis.set_turn_pid(-90, TURN_SPEED);
  chassis.wait_drive();

  //Turn intake on to suck up pesky 1 disk that is in fron of the roller
  Intake.move_relative(15, 600);
  
  //Drive forward almost to roller
  chassis.set_drive_pid(26, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Drive up and slowely press into roller
  chassis.set_drive_pid(5, DRIVE_SPEED, true);
  Intake.brake();
  chassis.wait_drive();

  //Move roller and wait until complete
  Intake.move_relative(-3, 600);
	pros::delay(750);

  //Back up from 1st roller to be in line with second
  chassis.set_drive_pid(-15, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Line up roller mech with roller
  chassis.set_turn_pid(-180, TURN_SPEED);
  chassis.wait_drive();

  //Drive forward to second roller
  chassis.set_drive_pid(12, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Push up to second roller
  chassis.set_drive_pid(3, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Reset chassis to 0 for easier second half programming
  chassis.set_angle(-2);

  //Spin roller and wait until it is spun
  Intake.move_relative(-3, 600);
	pros::delay(750);

//4TH SHOT

  //Drive backward away from the roller and line up with the row of three disks
  chassis.set_drive_pid(-37, DRIVE_SPEED, true);
  chassis.wait_drive();

  //Turn to face the row of three disks
  chassis.set_turn_pid(-135, TURN_SPEED);
  chassis.wait_drive();

  //Turn intake on to suck up disks
  Intake.move_relative(65, 600);

  //Suck up two disks from the row
  chassis.set_drive_pid(30, 40, true);
  chassis.wait_drive();

  //Turn to be in line with goal
  chassis.set_turn_pid(-28, TURN_SPEED);
  chassis.wait_drive();

  //Drive forward to get a better shot
  chassis.set_drive_pid(-15, 80, true);
  chassis.wait_drive();

  //Stop intake before shooting
  Intake.brake();

  //Shoot + wait for disks to shoot
  Flywheel.move_relative(18, 600);
  pros::delay(300);
  
//5TH SHOT
  chassis.set_drive_pid(15, 80, true);
  chassis.wait_drive();
  
  chassis.set_turn_pid(-135, TURN_SPEED);
  chassis.wait_drive();

  Intake.move_relative(50, 600);

  chassis.set_drive_pid(20, 80, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-90, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(28, 70, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-135, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(20, 70, true);
  chassis.wait_drive();
  
  chassis.set_drive_pid(-34, 70, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-50, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(-25, 80, true);
  chassis.wait_drive();

  Intake.brake();
  Flywheel.move_relative(18, 600);
  pros::delay(500);
  
//6TH SHOT
  chassis.set_drive_pid(9, 80, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-135, TURN_SPEED);
  chassis.wait_drive();
  Intake.move_relative(60, 600);

  chassis.set_drive_pid(25, DRIVE_SPEED, true);
  chassis.wait_drive();
  pros::delay(500);

  chassis.set_drive_pid(33, 30, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-90, TURN_SPEED);
  chassis.wait_drive();
  
  chassis.set_drive_pid(-43, 80, true);
  chassis.wait_drive();

  Intake.brake();
  Flywheel.move_relative(18, 600);
  pros::delay(500);
  
//ENDGAME
  chassis.set_drive_pid(20, 80, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-45, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(35, 80, true);
  chassis.wait_drive();

  chassis.set_turn_pid(-135, TURN_SPEED);
  chassis.wait_drive();

  chassis.set_drive_pid(20, 80, true);
  chassis.wait_drive();

  Flywheel.move_relative(2, 600);
  pros::delay(150);
  expand.set_value(true);
  expandtwo.set_value(true);

  pros::delay(500);
  expand.set_value(false);
  expandtwo.set_value(false);


  pros::delay(1000);

  chassis.set_drive_pid(10, 80, true);
  chassis.wait_drive();

  chassis.set_drive_pid(-5, 80, true);
  chassis.wait_drive();













}



