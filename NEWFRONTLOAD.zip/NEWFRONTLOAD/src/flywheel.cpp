#include "main.h"
#include "pros/adi.h"
#include "pros/adi.hpp"
#include "pros/misc.h"
#include "pros/motors.h"

// Helpy functions
using pros::E_CONTROLLER_DIGITAL_L1;

void setFlywheel(int speed) { Flywheel = speed; }

void setIntake(int index) { Intake = index; }

// Driver Control functions
void SetFlywheelMotors() {
  int flywheelpower;
  int intakepower;

  if (pressy.get_value() == false) {
    intakepower = 127;
    flywheelpower = 127;
    pros::delay(5);

  }

  else if (pressy.get_value() == true) {
    if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
      Flywheel.move_relative(2, 600);
      Intake.move_relative(2, 600);
      pros::delay(250);

    }

    else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
      powerlimit.set_value(true);
      powerlimittwo.set_value(true);
      pros::delay(150);
      Flywheel.move_relative(2, 600);
      Intake.move_relative(2, 600);
      power.set_value(true);
      powertwo.set_value(true);
      pros::delay(500);
      power.set_value(false);
      powertwo.set_value(false);
      powerlimit.set_value(false);
      powerlimittwo.set_value(false);

    }

    else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_X)) {
      powerlimit.set_value(false);
      powerlimittwo.set_value(false);
      power.set_value(true);
      powertwo.set_value(true);
      Flywheel.move_relative(2, 600);
      Intake.move_relative(2, 600);
      pros::delay(500);
      power.set_value(false);
      powertwo.set_value(false);
    }

    else {
      powerlimit.set_value(false);
      intakepower = 0;
      flywheelpower = 0;

      if (dis.get() > 38) {
        if (controller.get_digital(E_CONTROLLER_DIGITAL_L1)) {
          intakepower = -127;
          flywheelpower = -127;
        }
      }

      if (dis.get() < 18) {
        if (controller.get_digital(E_CONTROLLER_DIGITAL_L1)) {
          intakepower = -127;
          flywheelpower = -127;
        }
      }
    }
  }

  if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2)) {
    intakepower = -127;
    flywheelpower = -127;
  }

  if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_LEFT)) {
    expand.set_value(true);
  }

  if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_RIGHT)) {
    expandtwo.set_value(true);
  }

  if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN)) {
    expand.set_value(true);
    expandtwo.set_value(true);
  }

  if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_Y)) {
    expandtwo.set_value(false);
    expand.set_value(false);
    pistonintake.set_value(false);
  }

  if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_UP)) {
    pistonintake.set_value(true);
  }

  setFlywheel(flywheelpower);
  setIntake(intakepower);
}
