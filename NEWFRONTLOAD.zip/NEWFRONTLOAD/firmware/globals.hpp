#include "pros/adi.hpp"
#include "pros/misc.hpp"
#include "pros/motors.hpp"


//Defining motors globally

extern pros::Motor Intake;
extern pros::Motor Flywheel;

//Defining CONTROLLER_MASTER

extern pros::ADIDigitalOut expand;
extern pros::ADIDigitalOut powertwo;
extern pros::ADIDigitalOut expandtwo;
extern pros::ADIDigitalOut power;
extern pros::ADIDigitalOut powerlimit;


extern pros::ADIButton pressy;
extern pros::ADIButton boost;


extern pros::Controller controller;
