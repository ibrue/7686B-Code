#pragma once

#include "EZ-Template/drive/drive.hpp"
#include "autons.hpp"

extern Drive chassis;

void CloseFive();
void CloseTwo();
void CloseEight();
void CloseMaxDisk();
void FarFive();
void FarTwo();
void FarEight();
void FarMaxDisk();
void WinPoint();
void Skills();

void default_constants();
void one_mogo_constants();
void two_mogo_constants();
void exit_condition_defaults();
void modified_exit_condition();