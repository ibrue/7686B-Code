#include "pros/adi.hpp"
#include "pros/distance.hpp"
#include "pros/misc.hpp"
#include "pros/motors.hpp"


//Defining motors globally

extern pros::Motor Intake;
extern pros::Motor Flywheel;

//Defining CONTROLLER_MASTER

extern pros::ADIDigitalOut expand;
extern pros::ADIDigitalOut powertwo;
extern pros::ADIDigitalOut expandtwo;
extern pros::ADIDigitalOut pistonintake;
extern pros::ADIDigitalOut power;
extern pros::ADIDigitalOut powerlimit;
extern pros::ADIDigitalOut powerlimittwo;
extern pros::Distance dis;
extern pros::Distance wall;

extern pros::ADIButton pressy;
extern pros::ADIButton boost;


extern pros::Controller controller;
