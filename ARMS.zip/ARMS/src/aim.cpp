#include "main.h"
#include "pros/adi.h"
#include "pros/adi.hpp"
#include "pros/misc.h"
#include "pros/vision.hpp"
#include "pros/vision.h"


//Void called in op control loop
void AimControl(){
    #define Goal 1
     pros::Vision::signature_from_utility(Goal,8973, 11143, 10058, -2119, -1053, -1586, 5.4, 0);
  pros::vision_object_s_t rtn = seeall.get_by_sig(0, Goal);
  









int turning;


//arms::chassis::turn(turning);

  }

