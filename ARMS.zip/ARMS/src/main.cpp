#include "main.h"
#include "lemlib/api.hpp"


// drivetrain motors
pros::Motor left_front_motor(12, false); // port 1, not reversed
pros::Motor left_back_motor(13, true); // port 2, not reversed
pros::Motor left_top_motor(14, true); // port 2, not reversed
pros::Motor right_front_motor(18, true); // port 3, reversed
pros::Motor right_back_motor(19, false); // port 4, reversed
pros::Motor right_top_motor(20, false); // port 2, not reversed

 
// drivetrain motor groups
pros::MotorGroup left_side_motors({left_front_motor, left_back_motor, left_top_motor});
pros::MotorGroup right_side_motors({right_front_motor, right_back_motor, right_top_motor});
 
// center tracking wheel sensor
pros::Rotation center_rot(4, false); // port 1, not reversed
 
// center tracking wheel construct
lemlib::TrackingWheel center_tracking_wheel(&center_rot, 2.75,0); // 2.75" wheel diameter, -4.6" offset from tracking center

// inertial sensor
pros::Imu inertial_sensor(17); // port 2

lemlib::Drivetrain_t drivetrain {
    &left_side_motors, // left drivetrain motors
    &right_side_motors, // right drivetrain motors
    10, // track width
    2.75, // wheel diameter
    480, // wheel rpm
};
 
// odometry struct
lemlib::OdomSensors_t sensors {
    &center_tracking_wheel, // vertical tracking wheel 1
    nullptr, // vertical tracking wheel 2
    nullptr, // horizontal tracking wheel 1
    nullptr, // we don't have a second tracking wheel, so we set it to nullptr
    &inertial_sensor // inertial sensor
};
 
// forward/backward PID
lemlib::ChassisController_t lateralController {
    10, // kP
    47, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
	8 //slew
};
 
// turning PID
lemlib::ChassisController_t angularController {
    2, // kP
    17, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
	8 //slew
};
 
// track width
float track_width = 11; // 15.5" track width

// create the chassis object
lemlib::Chassis chassis(drivetrain, lateralController, angularController, sensors);




/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
void initialize() {
    chassis.calibrate();
}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {
  chassis.setPose(68,0,270);
  chassis.follow("load.txt", 3000, 15);
  //chassis.moveTo(18, 1, 1000,80);
  //chassis.turnTo(30, 5, 1000);
  //chassis.moveTo(0, 0, 1000, 80);







  

}

/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {
	pros::lcd::initialize();

	while (true) {

	CataControl();
	EndgameControl();
	AimControl();

    lemlib::Pose pose = chassis.getPose(); // get the current position of the robot
        pros::lcd::print(0, "x: %f", pose.x); // print the x position
        pros::lcd::print(1, "y: %f", pose.y); // print the y position
        pros::lcd::print(2, "heading: %f", pose.theta); // print the heading
		pros::delay(10);
	}
}
