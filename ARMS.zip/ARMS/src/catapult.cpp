#include "main.h"
#include "pros/adi.h"
#include "pros/adi.hpp"
#include "pros/misc.h"
#include "pros/motors.h"

//Sets the motor speed async
void setmotor(int speed){
  CataLeft = speed;
  CataRight = speed;
  }

//Void called in op control loop
void CataControl(){
  int motorspeed;

if(pressy.get_value() == false){
motorspeed = 127;
}

else if(pressy.get_value() == true){
if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)){
CataLeft.move_relative(2, 600);
CataRight.move_relative(2, 600);
pros::delay(250);

}

else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2)){
powerlimit.set_value(true);
CataLeft.move_relative(2, 600);
CataRight.move_relative(2, 600);
while (boost.get_value() == false) {
pros::delay(1);
}
power.set_value(true);
powertwo.set_value(true);
pros::delay(250);
power.set_value(false);
powertwo.set_value(false);
}

else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_X)){
powerlimit.set_value(false);
CataLeft.move_relative(2, 600);
CataRight.move_relative(2, 600);
while (boost.get_value() == false) {
pros::delay(1);
}
power.set_value(true);
powertwo.set_value(true);
pros::delay(250);
power.set_value(false);
powertwo.set_value(false);
}

else {
powerlimit.set_value(false);
motorspeed = 0;

}

}

  if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L1)){
  motorspeed = -127;
  }

  if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2)){
CataLeft.move_relative(-5, 600);
CataRight.move_relative(-5, 600);
pros::delay(500);
  }

setmotor(motorspeed);


}
