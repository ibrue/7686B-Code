#include "main.h"
#include "pros/adi.hpp"
#include "lemlib/api.hpp"

//Defining motors actually this time
pros::Motor CataLeft (2, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_ROTATIONS);
pros::Motor CataRight (9, pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_ROTATIONS);


//Defining Controller
pros::Controller controller(pros::E_CONTROLLER_MASTER);

//Defining Pneumatics
pros::ADIDigitalOut expand('D'); 
pros::ADIDigitalOut expandtwo('E'); 

pros::ADIDigitalOut powertwo('B'); 
pros::ADIDigitalOut power('C'); 

//Defining Stop
pros::ADIButton pressy('A'); 

pros::ADIButton boost('F'); 
pros::ADIDigitalOut powerlimit('G'); 

pros::Vision seeall (6);





