#include "main.h"
#include "pros/adi.h"
#include "pros/adi.hpp"
#include "pros/misc.h"
#include "pros/motors.h"

//Void called in op control loop
void EndgameControl(){
 
if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_Y)){
expand.set_value(true);
expandtwo.set_value(true);
pros::delay(500);
}

if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_A)){
expand.set_value(false);
expandtwo.set_value(false);
}

}
