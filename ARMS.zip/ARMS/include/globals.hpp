#include "pros/adi.hpp"
#include "pros/misc.hpp"
#include "pros/motors.hpp"
#include "pros/vision.hpp"


//Defining motors globally

extern pros::Motor CataLeft;
extern pros::Motor CataRight;

//Defining CONTROLLER_MASTER

extern pros::ADIDigitalOut expand;
extern pros::ADIDigitalOut powertwo;
extern pros::ADIDigitalOut expandtwo;
extern pros::ADIDigitalOut power;
extern pros::ADIDigitalOut powerlimit;


extern pros::ADIButton pressy;
extern pros::ADIButton boost;


extern pros::Controller controller;

extern pros::Vision seeall;
