//Helpy functions
void setmotor(int speed);
//Driver Control functions
void CataControl();
