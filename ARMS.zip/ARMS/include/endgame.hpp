void EndgameControl();
